# Tandemhopper Next.js V1

Erste CMS-fähige Next.js-Struktur auf Basis des freigegebenen V3-Designs.

## Bereits enthalten
- responsive Startseite
- Geschichten-Archiv mit Kategorien
- dynamische Artikelseiten (`/geschichten/[slug]`)
- Spiel-Metadaten
- Galerien am Artikelanfang oder -ende
- Lightbox
- Über-uns-Seite
- `/studio` als vorbereiteter Platz für das spätere CMS

## Content heute
Artikel liegen vorübergehend strukturiert in `lib/articles.js`. Das ist absichtlich nur die Übergangslösung. Sobald ein CMS-Projekt verbunden ist, wird dieser Daten-Layer ersetzt, ohne das Design der Website neu bauen zu müssen.

## Geplanter CMS-Datensatz
Jeder Artikel erhält: Titel, Untertitel, Kategorie, Teaser, Datum, Titelbild, Fließtext-Blöcke, Galerie, Galerieposition sowie optionale Spielinfos (Teams, Wettbewerb, Stadion, Zuschauer, Ergebnis).
